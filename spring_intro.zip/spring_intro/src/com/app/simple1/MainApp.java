package com.app.simple1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {

      ApplicationContext context = 
                          new ClassPathXmlApplicationContext("beans1.xml");
      System.out.println("ctx loaded ");

      HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
      obj.getMessage();
   //  ((ClassPathXmlApplicationContext)context).registerShutdownHook();
    ((ClassPathXmlApplicationContext)context).close();
   }
}
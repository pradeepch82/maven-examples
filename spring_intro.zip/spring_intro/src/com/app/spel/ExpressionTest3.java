package com.app.spel;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ExpressionTest3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"spel_beans2.xml");
		NumberGuess2 guess = ctx.getBean(NumberGuess2.class);
		System.out.println("Random Number=" + guess.getRandomNumber());
		System.out.println("User Home " + guess.getUserHome());

	}

}

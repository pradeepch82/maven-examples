package com.app.simple8;

import org.springframework.beans.factory.annotation.Value;

public class HelloWorld {
	@Value("Hello Everyone ...")
   private String message;

   
   public void getMessage(){
      System.out.println("Your Message : " + message);
   }
  
}
package com.app.simple8;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {
	   ApplicationContext ctx = 
			   new AnnotationConfigApplicationContext(HelloWorldConfig.class);
			   
			   HelloWorld hello =(HelloWorld) ctx.getBean("abc");
			   	//or other option is as below
			   //HelloWorld hello=ctx.getBean(HelloWorld.class);
			  
			   hello.getMessage();
      
     

   }
}
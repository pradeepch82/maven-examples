package com.app.simple7.anno;

public interface PersonIntf {
	String show();

}

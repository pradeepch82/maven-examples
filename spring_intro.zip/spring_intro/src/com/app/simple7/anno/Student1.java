package com.app.simple7.anno;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("stud1")
public class Student1 implements StudentIntf{
	
	@Autowired(required=true)
	@Qualifier("person1")
	private PersonIntf person;
	
	@Value("Spring")
   private String course;
	
	
	@Override
	public String show() {
		// TODO Auto-generated method stub
		return "Student Dtls "+person.show()+", course=" + course;
				
	}


	
	

  }
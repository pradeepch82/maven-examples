package com.app.simple7.anno;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("person2")
public class Person2 implements PersonIntf {
	
	
	@Value("28")
   private Integer age;
	
	@Value("Rahul")
   private String name;

	@Override
	public String show() {
		// TODO Auto-generated method stub
		return "Name ="+name+" Age = "+age;
	}

}

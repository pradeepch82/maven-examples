package com.app.simple7.anno;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
   public static void main(String[] args) {
      ApplicationContext context = 
             new ClassPathXmlApplicationContext("beans7-anno.xml");

      StudentIntf student= (StudentIntf) context.getBean("stud2");

      System.out.println(student.show());
     //o/p for stud2  will show init BUT what about clean-up code?
    
      
    ((ClassPathXmlApplicationContext) context).close();

   }
}
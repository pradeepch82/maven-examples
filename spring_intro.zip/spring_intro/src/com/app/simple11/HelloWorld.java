package com.app.simple11;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class HelloWorld {
	@Value("#{systemProperties['java.home']}")
   private String message;

  
   public void getMessage(){
      System.out.println("Your Message : " + message);
   }
}
package com.app.simple3;

public class TextEditor {
   private SpellChecker spellChecker;
   /*public TextEditor() {
	// TODO Auto-generated constructor stub
   }*/

   public TextEditor(SpellChecker spellChecker123) {
      System.out.println("Inside TextEditor constructor." );
      this.spellChecker = spellChecker123;
   }
   public void spellCheck() {
      spellChecker.checkSpelling();
   }
}
package com.app.simple12;

import java.sql.Date;

import org.springframework.context.ApplicationEvent;

public class CustomEvent extends ApplicationEvent {

	public CustomEvent(Object source) {
		super(source);
	}

	public String toString() {
		return "My Custom Event occurred @ "+new Date(getTimestamp());
	}
}
package com.app.simple5.autowire;

public class AdvancedSpellChecker implements SpellChecker{
   public AdvancedSpellChecker(){
      System.out.println("Inside Advanced SpellChecker constructor." );
   }

   @Override
   public void checkSpelling(){
      System.out.println("Inside advanced checkSpelling." );
   }
   
}
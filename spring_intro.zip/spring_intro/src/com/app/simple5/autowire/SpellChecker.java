package com.app.simple5.autowire;

public interface SpellChecker {
	void checkSpelling();

}

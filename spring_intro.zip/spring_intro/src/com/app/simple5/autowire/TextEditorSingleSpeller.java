package com.app.simple5.autowire;

public class TextEditorSingleSpeller {
	private SpellChecker advSpellChecker;

	
	


	public SpellChecker getAdvSpellChecker() {
		return advSpellChecker;
	}





	public void setAdvSpellChecker(SpellChecker advSpellChecker) {
		this.advSpellChecker = advSpellChecker;
	}





	public void spellCheck() {
		
		advSpellChecker.checkSpelling();
	}
}